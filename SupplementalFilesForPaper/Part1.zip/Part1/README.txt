This directory Part1 lists the extracted genes of 17 vertebrates

ANOCA	       lizard	   Anolis carolinensis	
BOVIN	       cow	   Bos taurus	
CANFA	       dog	   Canis familiaris
CHICK	       chicken	   Gallus gallus
DANRE	       zebrafish   Danio rerio
FELCA	       cat	   Felis catus
HORSE	       horse	   Equus caballus
HUMAN	       human	   Homo Sapiens
MACMU	       macacque	   Macaca mulatta
MONDO	       opossum	   Monodelphis domestica
MOUSE	       mouse	   Mus musculus
ORNAN	       platypus	   Ornithorhynchus anatinus	
PANTR	       chimpanzee  Pan troglodytes
PIG	       pig	   Sus scrofa
RAT	       rat	   Rattus norvegicus	
TAKRU	       pufferfish  Takifugu rubripes
XENTR	       frog	   Xenopus tropicalis


**********

File PANTHERnode_gene.tab lists the PANTHER node ids and their corresponding genes.
For internal nodes, the PTN id is listed in the second column.(PTN id is used for tracking internal nodes among differnt versions of PANTHER databases)


**********

relation.table lists the relationship among the extant genes.
This file is essential for running iadhore-3.
Each line lists 2 genes that are "homologous".
In our analysis, descendant genes of the same duplication node at early vertebrates are considered "homologous".

**********


Each directory lists the extracted genes of a species.
For example, Human genes are listed in HUMAN8760 according to chromosomes.

Each of the .lst file list extracted genes in a chromosome or scaffold.

For example: 1.lst lists the extracted genes of chromosome 1, one gene per line. The genes of the orders follows their coorinates in the chromosome.

The coordinates are extracted from Ensemble-Biomart
http://useast.ensembl.org/biomart/martview/a9c9946c9685638f510a6831147eed0a


**********

i-adhore3 is downloaded from http://bioinformatics.psb.ugent.be/webtools/i-adhore/licensing/


totalcontrol.ini is the control file for i-adhore-3

To use the data here:
i-adhore totalcontrol.ini

**********










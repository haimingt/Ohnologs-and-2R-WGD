The part2 lists synteny evidences summarized from the genes extracted in Part1 including multiplicons and the paralogous gene pairs with different levels of synteny evidences.

The adhore_result directory lists results from the i-adhore3 using the extracted genes in part1.


*********

The summarized results are in evidence.txt and evidence_sum.txt


*********

For evidence.txt:

The synteny evidences are summarized from the result files in adhore_result.

For each duplication node at early vertebrates.
Genes of the same species are examinied to see if there is synteny evidence.
There are 3 levels of evidences:

Direct evidence: the 2 genes appear in the same multiplicon
1 level: the 2 genes don't appear in the same multiplicon, but are connected by a 3rd gene. There might be multiple choices the 3rd gene. They are seperated by ";"
2 leve: The 2 genes need to be connected by 2 genes. multiple choices are seperated by ";"

If more accurate level of evidence is presnt, then the less accurate levels are not listed.
For example, if direct evidence is present, then 1 level and 2 level evidences are not listed.


Below is an example:

************* PTHR12422_AN21 **************                                          # the duplication node id
** CHICK **                                                                          # the species
                        PTHR12422_AN91:PTHR12422_AN200 -> DirectConnection||         # AN91 and AN200 are 2 chickedn genes that appear in the same multiplicon
			
** HUMAN **
                        PTHR12422_AN76:PTHR12422_AN183 -> DirectConnection||
** MACMU **
                        PTHR12422_AN79:PTHR12422_AN186 -> DirectConnection||
** CANFA **
                        PTHR12422_AN53:PTHR12422_AN162 -> 1 level PTHR12422_AN200;PTHR1242
2_AN171;PTHR12422_AN189;PTHR12422_AN183;||

# AN53 and AN162 are 2 CANFA genes, they don't appear in the same multiplicon. But both AN53 and AN200 and AN200 and AN162 appear in the same multiplicons. Thus, AN53 and AN162 are connected by "1 level" evidence. There are other choices of connections: AN171, AN189 and AN183.


** BOVIN **
                        PTHR12422_AN46:PTHR12422_AN155 -> DirectConnection||
** PIG **
                        PTHR12422_AN156:PTHR12422_AN47 -> 2 level PTHR12422_AN193 PTHR1242
2_AN50;PTHR12422_AN48;PTHR12422_AN86;PTHR12422_AN63;PTHR12422_AN46;PTHR12422_AN64;||PTHR12
422_AN156:PTHR12422_AN47 -> 2 level PTHR12422_AN155 PTHR12422_AN50;PTHR12422_AN48;PTHR1242
2_AN86;PTHR12422_AN63;PTHR12422_AN46;PTHR12422_AN64;||PTHR12422_AN156:PTHR12422_AN47 -> 2
level PTHR12422_AN195 PTHR12422_AN50;PTHR12422_AN48;PTHR12422_AN105;PTHR12422_AN86;PTHR124
22_AN63;PTHR12422_AN46;PTHR12422_AN64;||

# AN156 and AN47 are 2 PIG genes. AN156 and AN193 appear in the same multiplicon; AN193 and AN50 in the same multiplicon; AN50 and AN47 in the same multiplicon. Thus AN156 and AN47 are connected by "2 level" evidence.
All choices are listed.



********************
For evidence_sum.txt

The synteny evidences on extant genes are summarzied to the reconstructed ancestral genes at early vertebrates.
(The speciation nodes that are direct descendants of the duplication nodes at early vertebrates)

The first column lists the duplication nodes at early vertebrates.
The second column lists the 2 direct descendants of the duplication node in the first column.
The third column lists the level of evidences. 1 for "direct evidence"; 2 for "1 level" evidence; 3 for "2 level" evidence; and "no_evidence" if none of the evidences are found.
The fourth column lists the vertebrate species that have the evidences in the 3rd column.


A duplication node at early vertebrates may have more than 2 direct descendant speciation nodes at early vertebrates. All combinations of the descendant speciation nodes are examined for synteny evidences. 

For example, PTHR10024_AN1619 has 3 descendants: PTHR10024_AN1620, PTHR10024_AN1686, and PTHR10024_AN1750.
Each represents one copy of ancestral gene in early vertebrates.
We look at the synteny evidences for 3 pairs:
 between PTHR10024_AN1620 and PTHR10024_AN1686
 between PTHR10024_AN1620 and PTHR10024_AN1750
 between PTHR10024_AN1686 and PTHR10024_AN1750	






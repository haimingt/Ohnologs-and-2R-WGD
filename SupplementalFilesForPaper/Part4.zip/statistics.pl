my %sum_evi;

foreach my $ii (0..100){
    my %sum;
    my $rf = "./random_$ii/adhore_result/synteny_conservation_summary.txt";

    open IN, "< $rf" or die;
    while(<IN>){
	chomp;
	my @a = split(/,/);

	my $evi = $a[4];
	my $node = $a[0];
	
	unless (exists $sum{$node}){
	    $sum{$node} = $evi;
	}
	elsif ($sum{$node} > $evi){
	    $sum{$node} = $evi;
	}	
    }
    close IN;


    foreach my $k (keys %sum){
	my $v = $sum{$k};
	$sum_evi{$ii}{$v}++;
    }
}

my %names;
$names{1} = "Direct Evidence";
$names{2} = "Level 1 Evidence";
$names{3} = "Level 2 Evidence";


foreach my $i (0..100){
    foreach my $j (1,2,3){
	my $v =0;
	foreach my $k (1..$j){
	
	    $v += $sum_evi{$i}{$k};

	}

	$n = $names{$j};
	$v = $v/2965;
	if ($i == 0){
	    
	    print "Original,$n,$v\n";
	}
	else{
	    print "Rand_$i,$n,$v\n";
	}
    }
}


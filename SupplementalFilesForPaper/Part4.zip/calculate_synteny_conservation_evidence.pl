## the script is to summarize the synteny conservation evidence
## from the adhore_results

## to basically describe:

# For any pair of paralogs (genes of the same species) that are descendants
# of the a duplication node
## this info could be obtained from the ../Part3/ohnologs.csv

## we can save this file first to a file for all possible pairs to examine

## direct evidence
## first level evidence
## second level evidence

# number of duplication nodes at early vertebrates that have direct evidence or better
## first level or better
## second level or better

use strict;
use warnings;

my %genepairs;

my $genepairfile = "./gene_paris_same_species.csv";


if (-e $genepairfile){
    open IN, "< $genepairfile" or die "cannot open $genepairfile";
    while(<IN>){
	chomp;
	my @a = split(/,/);
	$genepairs{$a[0]}{$a[1]}{$a[2]} = 1;
	# duplication node, species , gene pair
    }
    close IN;
}
else{
    my $infofile = "../Part3/ohnologs.csv";

    my %map;
    my %other;

    open INF, "< $infofile" or die;
    my $first = <INF>;
    while(<INF>){
	chomp;
	my @a = split(/,/);

	my $s = $a[4];
	$map{$s}{$a[2]} = $a[0];
	$other{$s}{$a[2]} = $a[1];
	
    }
    close INF;


    open OUT, "> $genepairfile" or die;
    
    foreach my $s (keys %map){
	my @keys = keys %{$map{$s}};
	my $size = scalar @keys;
	
	foreach my $kk (0..$size-2){
	    foreach my $jj ($kk+1..$size-1){
		my $k = $keys[$kk];
		my $j = $keys[$jj];
		next if ($k eq $j);
		next unless ($map{$s}{$k} eq $map{$s}{$j});
		next if ($other{$s}{$k} eq $other{$s}{$j});
		
		print OUT "$map{$s}{$k},$s,$k;$j\n";
	    }
	}
    }

    close OUT;
}


##########
# now start with the actual work

my %evidences;

foreach my $ii (0..100){
    next unless ($ii < 1);
    my $f = "./random_$ii/adhore_result/multiplicon_pairs.txt";

    print "\n\nworking on $f\n";
    open IN, "< $f" or die;
    my $first = <IN>;
    while(<IN>){
	chomp;
	my @a = split(/\t| +/);
	$evidences{$ii}{$a[2]}{$a[3]} = 1;
	$evidences{$ii}{$a[3]}{$a[2]} = 1;
    }

    close IN;

    my %newevidences;
    foreach my $key (keys %{$evidences{$ii}}){
	my @cons = keys %{$evidences{$ii}{$key}};
	my $scons = @cons;
	foreach my $i (0..$scons-2){
	    foreach my $j ($i+1..$scons-1){
		unless (exists $evidences{$ii}{$cons[$i]}{$cons[$j]}){
		    $newevidences{$ii}{$cons[$i]}{$cons[$j]} = 2;
		}
		unless (exists $evidences{$ii}{$cons[$j]}{$cons[$i]}){
		    $newevidences{$ii}{$cons[$j]}{$cons[$i]} = 2;
		}
	    }
	}
    }

    foreach my $i (keys %newevidences){
	foreach my $j (keys %{$newevidences{$i}}){
	    foreach my $k (keys %{$newevidences{$i}{$j}}){
		$evidences{$i}{$j}{$k} = $newevidences{$i}{$j}{$k};
	    }
	}
    }

    undef %newevidences ;

    foreach my $key (keys %{$evidences{$ii}}){
	my @cons = keys %{$evidences{$ii}{$key}};
	my $scons = @cons;
	foreach my $i (0..$scons-2){
	    foreach my $j ($i+1..$scons-1){
		unless (exists $evidences{$ii}{$cons[$i]}{$cons[$j]}){
		    $newevidences{$ii}{$cons[$i]}{$cons[$j]} = 3;
		}
		unless (exists $evidences{$ii}{$cons[$j]}{$cons[$i]}){
		    $newevidences{$ii}{$cons[$j]}{$cons[$i]} = 3;
		}
	    }
	}
    }


    foreach my $i (keys %newevidences){
	foreach my $j (keys %{$newevidences{$i}}){
	    foreach my $k (keys %{$newevidences{$i}{$j}}){
		$evidences{$i}{$j}{$k} = $newevidences{$i}{$j}{$k};
	    }
	}
    }

    

    my $rf = "./random_$ii/adhore_result/synteny_conservation_summary.txt";

    open OUT, "> $rf" or die;


    foreach my $node (keys %genepairs){
	next unless ($node =~ /PTHR/);
	foreach my $s (keys %{$genepairs{$node}}){
	    foreach my $pair(keys %{$genepairs{$node}{$s}}){
		my @split = split(/;/,$pair);

		my $g1 = $split[0]; my $g2 = $split[1];
		my $evi = $evidences{$ii}{$g1}{$g2};

		if ($evi){
		    print OUT "$node,$s,$g1,$g2,$evi\n";
		    print  "$ii,$node,$s,$g1,$g2,$evi\n";
		}
	    }
	}
    }
    
    close OUT;
}


## the script is to generate list of vertebrate genes by randomizing order

use strict;
use warnings;
use List::Util qw(shuffle);


foreach my $i (1..100){
    my $targetd = "./random_$i";
    unless (-e $targetd){
	mkdir($targetd);
    }

    my $ini = "../Part1/totalcontrol.ini";
    my $relation = "../Part1/relation.table";

    `cp $ini $targetd`;
    `cp $relation $targetd`;
    next;
    
    opendir(DH,"../Part1") or die;
    my @files= readdir(DH);
    closedir(DH);

    foreach my $spec (@files){
	if (-d "../Part1/$spec"){
	    print "working on $spec\n\n";
	    my $tmpd = "$targetd/$spec";
	    unless (-e $tmpd){
		mkdir($tmpd);
	    }

	    opendir(SD,"../Part1/$spec") or die;
	    my @lsts = readdir(SD);
	    closedir(SD);
	    foreach my $lst (@lsts){
		if ($lst =~ /.lst/){
		    &randomize("../Part1/$spec/$lst","$tmpd/$lst");
		}
	    }
	}
    }
}

sub randomize{
    my $infile = shift;
    my $outfile = shift;

    print "working on $infile\n";
    my @tmp;
    open IN, "< $infile" or die;
    while(<IN>){
	my $l = $_;
	chomp($l);
	if ($l =~ /PTHR/){
	    push(@tmp,$l);
	}
    }
    close IN;
    
    my @shuffled = shuffle @tmp;

    open OUT, "> $outfile" or die;
    
    foreach my $item (@shuffled){
	print OUT "$item\n";
    }
    close OUT;
}
